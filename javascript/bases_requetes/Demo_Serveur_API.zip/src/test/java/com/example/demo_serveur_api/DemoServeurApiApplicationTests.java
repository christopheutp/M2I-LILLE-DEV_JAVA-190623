package com.example.demo_serveur_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoServeurApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
