package com.example.demo_serveur_api.models;

import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Data
@Builder
public class BearDTO {
    private UUID id;
    private String name;
}
