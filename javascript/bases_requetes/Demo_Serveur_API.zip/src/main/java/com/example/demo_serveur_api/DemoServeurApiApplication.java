package com.example.demo_serveur_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoServeurApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoServeurApiApplication.class, args);
    }

}
